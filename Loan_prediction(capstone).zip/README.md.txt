Capstone Proposal


Using Supervised Learning to predict whether a
person is eligible for a loan or not.

Project: Capstone Project

This project requires Python 2.7 and the following Python libraries installed:
NumPy Pandas matplotlib scikit-learn
Data: This data set contains total of 614 rows and 13 columns. And our target variable �Loan_Status� is whether the person has eligible for loan or not. It contains 614 customers detailsdetails with 13 features for each customer which describes about the main details of the customer like what is the gender of the customer , marital status for the customer and his educational status ,whether he is employed or not etc these features are very useful to determine the financial status of the customer so that we can easily predict whether the person is eligible for loan or not. Dataset has been extracted from Kaggle.
Dataset Link: https://www.kaggle.com/ninzaami/loan-predication

Features
	Age: 
	Loan_ID
	Gender
	Married
	Dependents
	Education
	Self_Employed
	Applicant Income
	Co Applicant Income
	Loan Amount
	Loan Amount Term
	Credit History
	Property Area


Target Variable
Loan_Status: Whether the person eligible for loan or not ('Y' or 'N')



